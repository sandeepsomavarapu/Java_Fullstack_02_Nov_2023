package com.cap.dao;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cap.entity.Account;
import com.cap.entity.Transaction;

public class AccountDaoImpl implements AccountDao {
	int transactionId = 1000;
	EntityManager entityManager = UtilJava.getEntityManager();
	// persist,merge,remove,find

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public int createAccount(Account account) {
		entityManager.persist(account);
		int accNum = account.getAccNo();
		return accNum;
	}

	@Override
	public Account getAccountDetails(int accNo) {
		Account account = entityManager.find(Account.class, accNo);
		return account;
	}

	@Override
	public int withdrawAmuont(int accNo, int amountToWithdraw) {
		Account account = getAccountDetails(accNo);
		int exsistingBalance = account.getBalance();
		int updatedBalance = exsistingBalance - amountToWithdraw;
		account.setBalance(updatedBalance);// setting updated balance to db
		Transaction trans = new Transaction(++transactionId, "withdraw", new Date(), updatedBalance, exsistingBalance,
				accNo, 0);
		Set<Transaction> set = new HashSet<Transaction>();
		set.add(trans);
		account.setTransactions(set);
		entityManager.merge(account);

		return updatedBalance;
	}

	@Override
	public int depositAmount(int accNo, int amountToDeposit) {
		Account account = getAccountDetails(accNo);
		int exsistingBalance = account.getBalance();
		int updatedBalance = exsistingBalance + amountToDeposit;
		account.setBalance(updatedBalance);// setting updated balance to db
		Transaction trans = new Transaction(++transactionId, "deposit", new Date(), updatedBalance, exsistingBalance,
				accNo, 0);
		Set<Transaction> set = new HashSet<Transaction>();
		set.add(trans);
		account.setTransactions(set);
		entityManager.merge(account);
		return updatedBalance;
	}

	@Override
	public int transferAmount(int fromAccNo, int toAccNo, int amountToTransfer) {
		Account fromAccount = getAccountDetails(fromAccNo);
		int fromExsistingBalance = fromAccount.getBalance();
		Account toAccount = getAccountDetails(toAccNo);
		int toExsistingBalance = toAccount.getBalance();
		int fromUpdatedBalance = fromExsistingBalance - amountToTransfer;
		int toUpdatedBalance = toExsistingBalance + amountToTransfer;
		fromAccount.setBalance(fromUpdatedBalance);// setting updated balance to db
		toAccount.setBalance(toUpdatedBalance);// setting updated balance to db
		Transaction trans = new Transaction(++transactionId, "transfer", new Date(), fromUpdatedBalance,
				fromExsistingBalance, fromAccNo, toAccNo);
		Set<Transaction> set = new HashSet<Transaction>();
		set.add(trans);
		fromAccount.setTransactions(set);
		entityManager.merge(fromAccount);
		entityManager.merge(toAccount);
		return fromUpdatedBalance;
	}

	@Override
	public List<Transaction> printTransactions(int accNo) {
		TypedQuery<Transaction> trans = entityManager.createQuery("select t from Transaction t where t.fromAccountNo=?1",
				Transaction.class);
		trans.setParameter(1, accNo);

		return trans.getResultList();
	}
}
