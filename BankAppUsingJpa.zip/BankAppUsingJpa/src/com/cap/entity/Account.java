package com.cap.entity;

import java.util.Random;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Bank")
public class Account {
	@Column(name = "accNo", length = 15)
	@Id
	@GeneratedValue
	private int accNo;
	@Column(name = "name", length = 15)
	private String name;
	@Column(name = "fName", length = 15)
	private String fName;
	@Column(name = "address", length = 20)
	private String address;
	@Column(name = "balance", length = 15)
	private int balance;
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "accid")
	private Set<Transaction> transactions;

	public Account(String name, String fName, String address, int balance, Set<Transaction> transactions) {
		super();
		this.name = name;
		this.fName = fName;
		this.address = address;
		this.balance = balance;
		this.transactions = transactions;
	}

	public Set<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(Set<Transaction> transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "Account Info : \n accNum=" + accNo + ", name=" + name + ", fName=" + fName + ", address=" + address
				+ ", balance=" + balance + "\n";
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public Account() {
		// TODO Auto-generated constructor stub
	}
}