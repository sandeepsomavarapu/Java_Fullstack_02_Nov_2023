import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class LoginTest {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("****Login App****");
			System.out.println("1.Login");
			System.out.println("2.Register");
			int option = scan.nextInt();
//		1)loading the driver class
			Class.forName("com.mysql.cj.jdbc.Driver");
//		2)creating the connection
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/india", "root", "rpsconsulting");

			switch (option) {
			case 1:
				System.out.println("Enter your Username: ");
				String username = scan.next();
				System.out.println("Enter your password: ");
				String password = scan.next();
				PreparedStatement stmt = conn.prepareStatement("select * from gmail where username=? and password =?");
				stmt.setString(1, username);
				stmt.setString(2, password);
				ResultSet result = stmt.executeQuery();
				if (result.next())
					System.out.println("Login Success");
				else
					System.out.println("Enter valid Credentials");
				break;
			case 2:
				System.out.println("Enter your userid: ");
				int userid = scan.nextInt();
				System.out.println("Enter your Username: ");
				username = scan.next();
				System.out.println("Enter your password: ");
				password = scan.next();
				stmt = conn.prepareStatement("insert into gmail values(?,?,?)");
				stmt.setInt(1, userid);
				stmt.setString(2, username);
				stmt.setString(3, password);
				int re = stmt.executeUpdate();
				if (re > 0)
					System.out.println("Registration Success");
				else
					System.out.println("somthing went wrong ");
				break;
			default:
				conn.close();
				System.out.println("Thank you !!");
				System.exit(0);
				break;

			}
		}
	}
}
