package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Product;
import com.example.demo.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	ProductService service;

	@PostMapping("/insertProduct") // http://localhost:1212/products/insertProduct
	public String addProduct(@RequestBody Product product) {
		return service.addProduct(product);
	}

	@PutMapping("/editProduct") // http://localhost:1212/products/editProduct
	public String updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}

	@DeleteMapping("/removeProduct/{pid}") // http://localhost:1212/products/removeProduct/123
	public String deleteProduct(@PathVariable("pid") int productId) {
		return service.deleteProduct(productId);
	}

	@GetMapping("/fetchProduct/{pid}") // http://localhost:1212/products/fetchProduct/123
	public Product getProduct(@PathVariable("pid") int productId) {
		return service.getProduct(productId);
	}

	@GetMapping("/getAll") //// http://localhost:1212/products/getAll
	public List<Product> getAllProducts() {
		return service.getAllProducts();
	}

	@GetMapping("/getAllBetweenPrice/{iprice}/{fprice}") //// http://localhost:1212/products/getAllBetweenPrice/2000/4000
	public List<Product> getAllProductBetweenPrice(@PathVariable("iprice") int intialPrice,
			@PathVariable("fprice") int finalPrice) {
		return service.getAllProductBetweenPrice(intialPrice, finalPrice);
	}

	@GetMapping("/getAllByCategory/{category}") //// http://localhost:1212/products/getAllByCategory/elctronics
	public List<Product> getAllProductByCategory(@PathVariable("category") String productCategory) {
		return service.getAllProductByCategory(productCategory);
	}

	@GetMapping("/getAllByBrand/{brand}") //// http://localhost:1212/products/getAllByBrand/samsung
	public List<Product> getAllProductsByBrand(@PathVariable("brand") String productBrand) {
		return service.getAllProductsByBrand(productBrand);
	}

}
