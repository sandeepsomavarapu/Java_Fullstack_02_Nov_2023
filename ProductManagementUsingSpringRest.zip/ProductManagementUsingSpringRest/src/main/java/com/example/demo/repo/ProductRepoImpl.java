package com.example.demo.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.entity.Product;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

@Repository // @Component,@Service
public class ProductRepoImpl implements ProductRepo {
	@PersistenceContext
	EntityManager entityManager;// persist,merge,remove,find,createQuery

	@Override
	public String addProduct(Product product) {
		entityManager.persist(product);
		return "Product Saved Sucessfully";
	}

	@Override
	public String updateProduct(Product product) {
		entityManager.merge(product);
		return "Product Updated Successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		entityManager.remove(getProduct(productId));
		return "Product removed Successfully";
	}

	@Override
	public Product getProduct(int productId) {
		Product product = entityManager.find(Product.class, productId);
		return product;
	}

	@Override
	public List<Product> getAllProducts() {
		List<Product> products = entityManager.createQuery("select p from Product p", Product.class).getResultList();
		return products;
	}

	@Override
	public List<Product> getAllProductBetweenPrice(int intialPrice, int finalPrice) {
		TypedQuery<Product> query = entityManager
				.createQuery("select p from Product p where p.productPrice between ?1 and ?2", Product.class);
		query.setParameter(1, intialPrice);
		query.setParameter(2, finalPrice);
		query.getResultList();

		return query.getResultList();
	}

	@Override
	public List<Product> getAllProductByCategory(String productCategory) {
		TypedQuery<Product> query = entityManager.createQuery("select p from Product p where p.productCategory=?1",
				Product.class);
		query.setParameter(1, productCategory);
		return query.getResultList();
	}

	@Override
	public List<Product> getAllProductsByBrand(String productBrand) {
		TypedQuery<Product> query = entityManager.createQuery("select p from Product p where p.productBrand=?1",
				Product.class);
		query.setParameter(1, productBrand);
		return query.getResultList();
	}

}
