package com.example.demo.repo;

import java.util.List;

import com.example.demo.entity.Product;

public interface ProductRepo {
	public abstract String addProduct(Product product);

	public abstract String updateProduct(Product product);

	public abstract String deleteProduct(int productId);

	public abstract Product getProduct(int productId);

	public abstract List<Product> getAllProducts();

	public abstract List<Product> getAllProductBetweenPrice(int intialPrice, int finalPrice);

	public abstract List<Product> getAllProductByCategory(String productCategory);

	public abstract List<Product> getAllProductsByBrand(String productBrand);
}
