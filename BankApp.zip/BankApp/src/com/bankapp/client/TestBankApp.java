package com.bankapp.client;

import java.util.HashMap;
import java.util.Scanner;

import com.bankapp.models.Account;
import com.bankapp.models.Address;

public class TestBankApp {

	public static void main(String[] args) {
		HashMap<Integer, Account> accounts = new HashMap<Integer, Account>();
		int accountId = 1000;
		String accountHolderName = null;
		String accountType = null;
		float accountBalance = 0.0f;
		String branch = null;
		long contact = 0;
		Address address;
		int hno = 0;
		String colony = null;
		int pincode = 0;
		String city = null;
		Account account = null;
		while (true) {
			System.out.println("********XYZ BANK APPLICATION********* ");
			System.out.println("Choose Option");
			System.out.println("1) Create Account");
			System.out.println("2) Account Info");
			System.out.println("3) Withdraw");
			System.out.println("4) Deposit");
			System.out.println("5) FundTransfer");
			System.out.println("6) Print Transactions");
			System.out.println("7) Exit");
			Scanner scanner = new Scanner(System.in);
			int option = scanner.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Details to create account");
				++accountId;
				System.out.println("Enter your name ");
				accountHolderName = scanner.next();
				System.out.println("Enter your Account Type ");
				accountType = scanner.next();
				System.out.println("Enter your Account Balance ");
				accountBalance = scanner.nextFloat();
				System.out.println("Enter your Account Branch ");
				branch = scanner.next();
				System.out.println("Enter your Contact No ");
				contact = scanner.nextLong();

				System.out.println("Enter your Hno ");// hno,colony,city,pincode
				hno = scanner.nextInt();
				System.out.println("Enter your Colonyname ");
				colony = scanner.next();// nextLine()
				System.out.println("Enter your Pincode ");
				pincode = scanner.nextInt();
				System.out.println("Enter your City ");
				city = scanner.next();
				address = new Address(hno, colony, pincode, city);
				account = new Account(accountId, accountHolderName, accountType, accountBalance, branch, contact,
						address);
				accounts.put(accountId, account);
				System.out.println("Account Created successfully with account no:" + accountId);
				System.out.println("Size" + accounts.size());

				break;
			case 2:
				System.out.println("Enter Account Id To view details");
				accountId = scanner.nextInt();
				account = accounts.get(accountId);
				System.out.println(account + " " + account.getAddress());
				break;
			case 3:
				System.out.println("Enter Account Id To withdraw");
				accountId = scanner.nextInt();
				System.out.println("Enter Amount  To withdraw");
				float withdrawlAmount = scanner.nextFloat();
				account = accounts.get(accountId);
				accountBalance = account.getAccountBalance();
				System.out.println("The Exsisting Balance is :" + accountBalance);
				float updatedBalance = accountBalance - withdrawlAmount;
				account.setAccountBalance(updatedBalance);
				accounts.put(accountId, account);
				System.out.println("the updated balance after withdrawl: " + updatedBalance);

				break;
			case 4:
				System.out.println("Enter Account Id To Deposit");
				accountId = scanner.nextInt();
				System.out.println("Enter Amount  To Deposit");
				float depositAmount = scanner.nextFloat();
				account = accounts.get(accountId);
				accountBalance = account.getAccountBalance();
				System.out.println("The Exsisting Balance is :" + accountBalance);
				float updatedBalance1 = accountBalance + depositAmount;
				account.setAccountBalance(updatedBalance1);
				accounts.put(accountId, account);
				System.out.println("the updated balance after deposit: " + updatedBalance1);
				break;
			case 5:
				break;
			case 6:
				break;
			case 7:
				System.out.println("Thank you !!!");
				System.exit(0);
				break;
			}

		}

	}

}
