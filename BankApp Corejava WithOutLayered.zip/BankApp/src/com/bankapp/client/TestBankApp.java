package com.bankapp.client;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import com.bankapp.models.Account;
import com.bankapp.models.Address;
import com.bankapp.models.Transaction;

public class TestBankApp {

	public static void main(String[] args) {
		HashMap<Integer, Account> accounts = new HashMap<Integer, Account>();
		HashMap<Integer, Transaction> transactions = new HashMap<Integer, Transaction>();
		int accountId = 1000;
		String accountHolderName = null;
		String accountType = null;
		float accountBalance = 0.0f;
		String branch = null;
		long contact = 0;
		Address address;
		int hno = 0;
		String colony = null;
		int pincode = 0;
		String city = null;
		Account account = null;
		int transactionId = 2000;
		while (true) {
			System.out.println("********XYZ BANK APPLICATION********* ");
			System.out.println("Choose Option");
			System.out.println("1) Create Account");
			System.out.println("2) Account Info");
			System.out.println("3) Withdraw");
			System.out.println("4) Deposit");
			System.out.println("5) FundTransfer");
			System.out.println("6) Print Transactions");
			System.out.println("7) Exit");
			Scanner scanner = new Scanner(System.in);
			int option = scanner.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Details to create account");
				++accountId;
				System.out.println("Enter your name ");
				accountHolderName = scanner.next();
				System.out.println("Enter your Account Type ");
				accountType = scanner.next();
				System.out.println("Enter your Account Balance ");
				accountBalance = scanner.nextFloat();
				System.out.println("Enter your Account Branch ");
				branch = scanner.next();
				System.out.println("Enter your Contact No ");
				contact = scanner.nextLong();

				System.out.println("Enter your Hno ");// hno,colony,city,pincode
				hno = scanner.nextInt();
				System.out.println("Enter your Colonyname ");
				colony = scanner.next();// nextLine()
				System.out.println("Enter your Pincode ");
				pincode = scanner.nextInt();
				System.out.println("Enter your City ");
				city = scanner.next();
				address = new Address(hno, colony, pincode, city);
				account = new Account(accountId, accountHolderName, accountType, accountBalance, branch, contact,
						address);
				accounts.put(accountId, account);
				System.out.println("Account Created successfully with account no:" + accountId);
				System.out.println("Size" + accounts.size());

				break;
			case 2:
				System.out.println("Enter Account Id To view details");
				accountId = scanner.nextInt();
				account = accounts.get(accountId);
				System.out.println(account + " " + account.getAddress());
				break;
			case 3:
				System.out.println("Enter Account Id To withdraw");
				accountId = scanner.nextInt();
				System.out.println("Enter Amount  To withdraw");
				float withdrawlAmount = scanner.nextFloat();
				account = accounts.get(accountId);
				accountBalance = account.getAccountBalance();
				System.out.println("The Exsisting Balance is :" + accountBalance);
				float updatedBalance = accountBalance - withdrawlAmount;
				account.setAccountBalance(updatedBalance);
				accounts.put(accountId, account);
				System.out.println("the updated balance after withdrawl: " + updatedBalance);
				Transaction withdrawTansaction = new Transaction(++transactionId, "Withdraw", new Date(),
						updatedBalance, accountId, 0);
				transactions.put(transactionId, withdrawTansaction);
				break;
			case 4:
				System.out.println("Enter Account Id To Deposit");
				accountId = scanner.nextInt();
				System.out.println("Enter Amount  To Deposit");
				float depositAmount = scanner.nextFloat();
				account = accounts.get(accountId);
				accountBalance = account.getAccountBalance();
				System.out.println("The Exsisting Balance is :" + accountBalance);
				float updatedBalance1 = accountBalance + depositAmount;
				account.setAccountBalance(updatedBalance1);
				accounts.put(accountId, account);
				System.out.println("the updated balance after deposit: " + updatedBalance1);
				Transaction depositTansaction = new Transaction(++transactionId, "Deposit", new Date(), updatedBalance1,
						accountId, 0);
				transactions.put(transactionId, depositTansaction);
				break;
			case 5:
				System.out.println("Enter From Account Id To Transfer");
				int fromAccountId = scanner.nextInt();
				System.out.println("Enter To Account Id for Transfer");
				int toAccountId = scanner.nextInt();
				System.out.println("Enter Amount  To Transfer");
				float transferAmount = scanner.nextFloat();

				Account fromAccount = accounts.get(fromAccountId);
				float fromAccountBalance = fromAccount.getAccountBalance();
				System.out.println("Balance Before FundTransfer :" + fromAccountBalance);
				float fromAccountRemainingBalance = fromAccountBalance - transferAmount;
				fromAccount.setAccountBalance(fromAccountRemainingBalance);
				accounts.put(fromAccountId, fromAccount);

				Account toAccount = accounts.get(toAccountId);
				float toAccountBalance = toAccount.getAccountBalance();
				float toAccountBalanceAfter = toAccountBalance + transferAmount;
				toAccount.setAccountBalance(toAccountBalanceAfter);
				accounts.put(toAccountId, toAccount);
				System.out.println("Balance After FundTransfer :" + fromAccountRemainingBalance);
				Transaction fundTransfer = new Transaction(++transactionId, "FundTransfer", new Date(),
						fromAccountRemainingBalance, fromAccountId, toAccountId);
				transactions.put(transactionId, fundTransfer);
				break;
			case 6:
				System.out.println("TransactionId   " + "   TransactionType   " + "  DateOfTransaction  "
						+ "  UpdatedBalance  " + "  FromAccount  " + " ToAccount ");
				Set<Integer> keys = transactions.keySet();

				Iterator<Integer> iterator = keys.iterator();
				while (iterator.hasNext()) {
					int transId = iterator.next();
					System.out.println(transactions.get(transId));
				}

				break;
			case 7:
				System.out.println("Thank you !!!");
				System.exit(0);
				break;
			}

		}

	}

}
