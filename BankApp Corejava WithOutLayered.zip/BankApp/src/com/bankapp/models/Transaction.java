package com.bankapp.models;

import java.util.Date;

public class Transaction {

	private int transactionId;
	private String transactionType;
	private Date dateOfTransaction;
	private float balanceAmount;
	private int fromAccountNo;
	private int toAccountNo;

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}

	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}

	public float getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(float balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public int getFromAccountNo() {
		return fromAccountNo;
	}

	public void setFromAccountNo(int fromAccountNo) {
		this.fromAccountNo = fromAccountNo;
	}

	public int getToAccountNo() {
		return toAccountNo;
	}

	public void setToAccountNo(int toAccountNo) {
		this.toAccountNo = toAccountNo;
	}

	public Transaction() {
		// TODO Auto-generated constructor stub
	}

	public Transaction(int transactionId, String transactionType, Date dateOfTransaction, float balanceAmount,
			int fromAccountNo, int toAccountNo) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.dateOfTransaction = dateOfTransaction;
		this.balanceAmount = balanceAmount;
		this.fromAccountNo = fromAccountNo;
		this.toAccountNo = toAccountNo;
	}

	@Override
	public String toString() {
		return transactionId + "               " + transactionType + "               " + dateOfTransaction + "              " + balanceAmount + " "
				+ fromAccountNo + "                   " + toAccountNo;
	}

}
