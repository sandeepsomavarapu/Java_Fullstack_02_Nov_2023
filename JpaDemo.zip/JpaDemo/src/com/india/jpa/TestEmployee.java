package com.india.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestEmployee {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mysql");
		EntityManager em=emf.createEntityManager();//persist,merge,remove,find
		
//		Employee emp=new Employee(125, "ramesh",12000,"hyderabad");
		em.getTransaction().begin();
//		em.persist(emp);//ORM
		Employee emp=em.find(Employee.class, 124);
		System.out.println(emp);
//		emp.setEmpName("sandeep");
//		emp.setEmpSal(23000);
//		em.merge(emp);
		em.remove(emp);
		em.getTransaction().commit();
	}

}
