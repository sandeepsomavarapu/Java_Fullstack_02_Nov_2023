package com.vitual.bankapp.dao;

import java.util.Set;

import com.vitual.bankapp.exceptions.AccountNotFoundException;
import com.vitual.bankapp.exceptions.InsufficientBalance;
import com.vitual.bankapp.models.Account;
import com.vitual.bankapp.models.Transaction;

public interface AccountDao {

	public abstract String createAccount(Account account);

	public abstract Account getAccountInfo(int accountNo) throws AccountNotFoundException;

	public abstract float withdrawAmount(int accountNo, float amountToWithdraw)
			throws AccountNotFoundException, InsufficientBalance;

	public abstract float depositAmount(int accountNo, float amountToDeposit) throws AccountNotFoundException;

	public abstract float fundTransfer(int fromAccountNo, int toAccountNo, float amountToTransfer)
			throws AccountNotFoundException, InsufficientBalance;

	public abstract Set<Transaction> printTransactions();

}
