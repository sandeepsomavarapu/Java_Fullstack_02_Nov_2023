package com.vitual.bankapp.dao;

import java.util.Set;

import com.vitual.bankapp.models.Account;
import com.vitual.bankapp.models.Transaction;

public interface AccountDao {

	public abstract String createAccount(Account account);

	public abstract Account getAccountInfo(int accountNo);

	public abstract float withdrawAmount(int accountNo, float amountToWithdraw);

	public abstract float depositAmount(int accountNo, float amountToDeposit);

	public abstract float fundTransfer(int fromAccountNo, int toAccountNo, float amountToTransfer);

	public abstract Set<Transaction> printTransactions();

}
