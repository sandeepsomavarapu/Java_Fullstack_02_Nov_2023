package com.vitual.bankapp.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.vitual.bankapp.models.Account;
import com.vitual.bankapp.models.Transaction;

public class AccountDAOImpl implements AccountDao {
	int transactionId = 2000;
	HashMap<Integer, Account> accounts = new HashMap<Integer, Account>();
	HashMap<Integer, Transaction> transactions = new HashMap<Integer, Transaction>();

	@Override
	public String createAccount(Account account) {
		accounts.put(account.getAccountId(), account);
		return "Account Created Successfully";
	}

	@Override
	public Account getAccountInfo(int accountNo) {

		return accounts.get(accountNo);
	}

	@Override
	public float withdrawAmount(int accountNo, float amountToWithdraw) {
		Account account = accounts.get(accountNo);
		float accountBalance = account.getAccountBalance();
		System.out.println("The Exsisting Balance is :" + accountBalance);
		float updatedBalance = accountBalance - amountToWithdraw;
		account.setAccountBalance(updatedBalance);
		accounts.put(accountNo, account);
		System.out.println("the updated balance after withdrawl: " + updatedBalance);
		Transaction withdrawTansaction = new Transaction(++transactionId, "Withdraw", new Date(), updatedBalance,
				accountNo, 0);
		transactions.put(transactionId, withdrawTansaction);
		return updatedBalance;
	}

	@Override
	public float depositAmount(int accountNo, float amountToDeposit) {
		Account account = accounts.get(accountNo);
		float accountBalance = account.getAccountBalance();
		System.out.println("The Exsisting Balance is :" + accountBalance);
		float updatedBalance = accountBalance - amountToDeposit;
		account.setAccountBalance(updatedBalance);
		accounts.put(accountNo, account);
		System.out.println("the updated balance after withdrawl: " + updatedBalance);
		Transaction withdrawTansaction = new Transaction(++transactionId, "Withdraw", new Date(), updatedBalance,
				accountNo, 0);
		transactions.put(transactionId, withdrawTansaction);
		return updatedBalance;
	}

	@Override
	public float fundTransfer(int fromAccountNo, int toAccountNo, float amountToTransfer) {
		Account fromAccount = accounts.get(fromAccountNo);
		float fromAccountBalance = fromAccount.getAccountBalance();
		System.out.println("Balance Before FundTransfer :" + fromAccountBalance);
		float fromAccountRemainingBalance = fromAccountBalance - amountToTransfer;
		fromAccount.setAccountBalance(fromAccountRemainingBalance);
		accounts.put(fromAccountNo, fromAccount);

		Account toAccount = accounts.get(toAccountNo);
		float toAccountBalance = toAccount.getAccountBalance();
		float toAccountBalanceAfter = toAccountBalance + amountToTransfer;
		toAccount.setAccountBalance(toAccountBalanceAfter);
		accounts.put(toAccountNo, toAccount);
		System.out.println("Balance After FundTransfer :" + fromAccountRemainingBalance);
		Transaction fundTransfer = new Transaction(++transactionId, "FundTransfer", new Date(),
				fromAccountRemainingBalance, fromAccountNo, toAccountNo);
		transactions.put(transactionId, fundTransfer);
		return fromAccountRemainingBalance;
	}

	@Override
	public Set<Transaction> printTransactions() {
		Set<Integer> keys = transactions.keySet();
		Set<Transaction> trans = new HashSet<Transaction>();
		Iterator<Integer> iterator = keys.iterator();
		while (iterator.hasNext()) {
			int transId = iterator.next();
			trans.add(transactions.get(transId));
		}
		return trans;

	}

}
