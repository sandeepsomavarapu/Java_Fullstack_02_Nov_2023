package com.vitual.bankapp.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.vitual.bankapp.exceptions.AccountNotFoundException;
import com.vitual.bankapp.exceptions.InsufficientBalance;
import com.vitual.bankapp.models.Account;
import com.vitual.bankapp.models.Transaction;

public class AccountDAOImpl implements AccountDao {
	int transactionId = 2000;
	HashMap<Integer, Account> accounts = new HashMap<Integer, Account>();
	HashMap<Integer, Transaction> transactions = new HashMap<Integer, Transaction>();

	@Override
	public String createAccount(Account account) {
		accounts.put(account.getAccountId(), account);
		return "Account Created Successfully";
	}

	@Override
	public Account getAccountInfo(int accountNo) {

		return accounts.get(accountNo);
	}

	@Override
	public float withdrawAmount(int accountNo, float amountToWithdraw)
			throws AccountNotFoundException, InsufficientBalance {
		Account account = accounts.get(accountNo);
		if (account != null) {
			float accountBalance = account.getAccountBalance();
			if (accountBalance > amountToWithdraw) {
				System.out.println("The Exsisting Balance is :" + accountBalance);
				float updatedBalance = accountBalance - amountToWithdraw;
				account.setAccountBalance(updatedBalance);
				accounts.put(accountNo, account);
				System.out.println("the updated balance after withdrawl: " + updatedBalance);
				Transaction withdrawTansaction = new Transaction(++transactionId, "Withdraw", new Date(),
						updatedBalance, accountNo, 0);
				transactions.put(transactionId, withdrawTansaction);
				return updatedBalance;
			} else {
				throw new InsufficientBalance("Insufficient Balance....");
			}
		} else {
			throw new AccountNotFoundException("Invalid Account Number....");
		}
	}

	@Override
	public float depositAmount(int accountNo, float amountToDeposit) throws AccountNotFoundException {
		Account account = accounts.get(accountNo);
		if (account != null) {
			float accountBalance = account.getAccountBalance();
			System.out.println("The Exsisting Balance is :" + accountBalance);
			float updatedBalance = accountBalance + amountToDeposit;
			account.setAccountBalance(updatedBalance);
			accounts.put(accountNo, account);
			System.out.println("the updated balance after withdrawl: " + updatedBalance);
			Transaction withdrawTansaction = new Transaction(++transactionId, "Withdraw", new Date(), updatedBalance,
					accountNo, 0);
			transactions.put(transactionId, withdrawTansaction);
			return updatedBalance;
		} else {
			throw new AccountNotFoundException("Invalid Account Number....");
		}
	}

	@Override
	public float fundTransfer(int fromAccountNo, int toAccountNo, float amountToTransfer)
			throws AccountNotFoundException, InsufficientBalance {

		Account fromAccount = accounts.get(fromAccountNo);
		Account toAccount = accounts.get(toAccountNo);
		float fromAccountRemainingBalance = 0.0f;
		if (fromAccount != null) {
			float fromAccountBalance = fromAccount.getAccountBalance();
			if (fromAccountBalance > amountToTransfer) {
				System.out.println("Balance Before FundTransfer :" + fromAccountBalance);
				fromAccountRemainingBalance = fromAccountBalance - amountToTransfer;
				fromAccount.setAccountBalance(fromAccountRemainingBalance);
				accounts.put(fromAccountNo, fromAccount);
			} else {
				throw new InsufficientBalance("Insufficient Balance....");
			}
		}
		if (toAccount != null) {
			float toAccountBalance = toAccount.getAccountBalance();
			float toAccountBalanceAfter = toAccountBalance + amountToTransfer;
			toAccount.setAccountBalance(toAccountBalanceAfter);
			accounts.put(toAccountNo, toAccount);
			System.out.println("Balance After FundTransfer :" + fromAccountRemainingBalance);
			Transaction fundTransfer = new Transaction(++transactionId, "FundTransfer", new Date(),
					fromAccountRemainingBalance, fromAccountNo, toAccountNo);
			transactions.put(transactionId, fundTransfer);
			return fromAccountRemainingBalance;
		} else {
			throw new AccountNotFoundException("Invalid Account Number....");
		}
	}

	@Override
	public Set<Transaction> printTransactions() {
		Set<Integer> keys = transactions.keySet();
		Set<Transaction> trans = new HashSet<Transaction>();
		Iterator<Integer> iterator = keys.iterator();
		while (iterator.hasNext()) {
			int transId = iterator.next();
			trans.add(transactions.get(transId));
		}
		return trans;

	}

}
