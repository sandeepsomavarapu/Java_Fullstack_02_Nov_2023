package com.vitual.bankapp.exceptions;

public class InsufficientBalance {

}
