package com.vitual.bankapp.exceptions;

public class InsufficientBalance extends Exception {
	public InsufficientBalance(String message) {
		super(message);
	}
}
