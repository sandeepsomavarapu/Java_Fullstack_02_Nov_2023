package com.vitual.bankapp.exceptions;

public class AccountNotFoundException extends Exception {
	public AccountNotFoundException(String message) {
		super(message);
	}
}
//1) make your class child class to anyone of the exception class 2)param constructor