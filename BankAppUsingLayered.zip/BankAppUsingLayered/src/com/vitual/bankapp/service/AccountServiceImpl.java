package com.vitual.bankapp.service;

import java.util.Set;

import com.vitual.bankapp.dao.AccountDAOImpl;
import com.vitual.bankapp.dao.AccountDao;
import com.vitual.bankapp.exceptions.AccountNotFoundException;
import com.vitual.bankapp.exceptions.InsufficientBalance;
import com.vitual.bankapp.models.Account;
import com.vitual.bankapp.models.Transaction;

public class AccountServiceImpl implements AccountService {
	AccountDao dao = new AccountDAOImpl();

	@Override
	public String createAccount(Account account) {

		return dao.createAccount(account);
	}

	@Override
	public Account getAccountInfo(int accountNo) throws AccountNotFoundException {

		return dao.getAccountInfo(accountNo);
	}

	@Override
	public float withdrawAmount(int accountNo, float amountToWithdraw) throws AccountNotFoundException, InsufficientBalance {

		return dao.withdrawAmount(accountNo, amountToWithdraw);
	}

	@Override
	public float depositAmount(int accountNo, float amountToDeposit) throws AccountNotFoundException {
		return dao.depositAmount(accountNo, amountToDeposit);
	}

	@Override
	public float fundTransfer(int fromAccountNo, int toAccountNo, float amountToTransfer) throws AccountNotFoundException, InsufficientBalance {

		return dao.fundTransfer(fromAccountNo, toAccountNo, amountToTransfer);
	}

	@Override
	public Set<Transaction> printTransactions() {

		return dao.printTransactions();
	}

}
