package com.vitual.bankapp.ui;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import com.vitual.bankapp.exceptions.AccountNotFoundException;
import com.vitual.bankapp.exceptions.InsufficientBalance;
import com.vitual.bankapp.models.Account;
import com.vitual.bankapp.models.Address;
import com.vitual.bankapp.models.Transaction;
import com.vitual.bankapp.service.AccountService;
import com.vitual.bankapp.service.AccountServiceImpl;

public class BankUI {

	public static void main(String[] args) throws AccountNotFoundException {
		AccountService service = new AccountServiceImpl();
		int accountId = 1000;
		String accountHolderName = null;
		String accountType = null;
		float accountBalance = 0.0f;
		String branch = null;
		long contact = 0;
		Address address;
		int hno = 0;
		String colony = null;
		int pincode = 0;
		String city = null;
		Account account = null;
		while (true) {
			System.out.println("********XYZ BANK APPLICATION********* ");
			System.out.println("Choose Option");
			System.out.println("1) Create Account");
			System.out.println("2) Account Info");
			System.out.println("3) Withdraw");
			System.out.println("4) Deposit");
			System.out.println("5) FundTransfer");
			System.out.println("6) Print Transactions");
			System.out.println("7) Exit");
			Scanner scanner = new Scanner(System.in);
			int option = scanner.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Details to create account");
				++accountId;
				System.out.println("Enter your name ");
				accountHolderName = scanner.next();
				System.out.println("Enter your Account Type ");
				accountType = scanner.next();
				System.out.println("Enter your Account Balance ");
				accountBalance = scanner.nextFloat();
				System.out.println("Enter your Account Branch ");
				branch = scanner.next();
				System.out.println("Enter your Contact No ");
				contact = scanner.nextLong();

				System.out.println("Enter your Hno ");// hno,colony,city,pincode
				hno = scanner.nextInt();
				System.out.println("Enter your Colonyname ");
				colony = scanner.next();// nextLine()
				System.out.println("Enter your Pincode ");
				pincode = scanner.nextInt();
				System.out.println("Enter your City ");
				city = scanner.next();
				address = new Address(hno, colony, pincode, city);
				account = new Account(accountId, accountHolderName, accountType, accountBalance, branch, contact,
						address);

				System.out.println(service.createAccount(account) + "  :" + accountId);
				break;
			case 2:
				System.out.println("Enter Account Id To view details");
				accountId = scanner.nextInt();

				try {
					System.out.println(service.getAccountInfo(accountId));
				} catch (AccountNotFoundException e) {
					System.out.println("Invalid Account Number....");
				}
				break;
			case 3:
				System.out.println("Enter Account Id To withdraw");
				accountId = scanner.nextInt();
				System.out.println("Enter Amount  To withdraw");
				float withdrawlAmount = scanner.nextFloat();
				float updatedBalance;
				try {
					updatedBalance = service.withdrawAmount(accountId, withdrawlAmount);
					System.out.println("After withdrawl updated balance " + updatedBalance);
				} catch (AccountNotFoundException e) {
					System.out.println("Invalid Account Number....");
				} catch (InsufficientBalance e) {
					System.out.println("Not Enough Balance to do withdraw....");
				}

				break;
			case 4:
				System.out.println("Enter Account Id To Deposit");
				accountId = scanner.nextInt();
				System.out.println("Enter Amount  To Deposit");
				float depositAmount = scanner.nextFloat();
				updatedBalance = service.depositAmount(accountId, depositAmount);
				System.out.println("After deposit updated balance " + updatedBalance);

				break;
			case 5:
				System.out.println("Enter From Account Id To Transfer");
				int fromAccountId = scanner.nextInt();
				System.out.println("Enter To Account Id for Transfer");
				int toAccountId = scanner.nextInt();
				System.out.println("Enter Amount  To Transfer");
				float transferAmount = scanner.nextFloat();
				try {
					updatedBalance = service.fundTransfer(fromAccountId, toAccountId, transferAmount);
					System.out.println("After Fundtransfer updated balance " + updatedBalance);
				} catch (AccountNotFoundException e) {
					System.out.println("Invalid Account Number....");
				} catch (InsufficientBalance e) {
					System.out.println("Not enough balance transfer....");
				}

				break;
			case 6:
				System.out.println("TransactionId   " + "   TransactionType   " + "  DateOfTransaction  "
						+ "  UpdatedBalance  " + "  FromAccount  " + " ToAccount ");
				Set<Transaction> transactions = service.printTransactions();

				Iterator<Transaction> iterator = transactions.iterator();
				while (iterator.hasNext()) {
					System.out.println(iterator.next());
				}

				break;
			case 7:
				System.out.println("Thank you !!!");
				scanner.close();
				System.exit(0);
				break;
			}

		}

	}

}